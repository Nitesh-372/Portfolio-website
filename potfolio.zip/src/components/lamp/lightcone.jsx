"use client";

export default function LightCone({ lampOn }) {

  if (!lampOn) return null;

  return (

    <div
      style={{
        position: "absolute",
        top: "70px",
        left: "50%",
        transform: "translateX(-50%)",
        width: "700px",
        height: "700px",
        background:
          "radial-gradient(ellipse at top,rgba(255,213,79,0.45),transparent 70%)",
        clipPath:
          "polygon(50% 0%, 0% 100%, 100% 100%)",
        pointerEvents: "none",
        opacity: 0.8,
        zIndex: "6"
      }}
    />

  );
}