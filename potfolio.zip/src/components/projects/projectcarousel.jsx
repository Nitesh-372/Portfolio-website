"use client";

import { useEffect, useRef, useState } from "react";
import projects from "@/data/projects";

export default function ProjectsCarousel({ lampOn }) {

  const sliderRef = useRef(null);
  const [activeIndex, setActiveIndex] = useState(0);
  const intervalRef = useRef(null);

  /* -----------------------------
     AUTO SLIDE FUNCTION
  ------------------------------*/

  const startAutoSlide = () => {

    if (intervalRef.current) return;

    intervalRef.current = setInterval(() => {

      const nextIndex = (activeIndex + 1) % projects.length;

      setActiveIndex(nextIndex);

      const slider = sliderRef.current;

      if (slider) {
        slider.scrollTo({
          left: nextIndex * 260, // card width + gap
          behavior: "smooth"
        });
      }

    }, 2000);

  };

  const stopAutoSlide = () => {
    clearInterval(intervalRef.current);
    intervalRef.current = null;
  };

  /* -----------------------------
     START AUTO SLIDE
  ------------------------------*/

  useEffect(() => {

    startAutoSlide();

    return () => stopAutoSlide();

  }, [activeIndex]);

  /* -----------------------------
     COMPONENT
  ------------------------------*/

  return (

    <div
      ref={sliderRef}

      className="hide-scrollbar"
      onMouseEnter={stopAutoSlide}
      onMouseLeave={startAutoSlide}

     
    
     

      onWheel={(e)=>{
        e.currentTarget.scrollLeft += e.deltaY;
      }}

      style={{
        width:"100%",
        maxWidth:"800px",
        minHeight:"320px",
        height:"auto",

        display:"flex",
        gap:"20px",

        overflowX:"auto",
        overflowY:"hidden",

        padding:"10px",

        scrollBehavior:"smooth"
      }}
    >

      {projects.map((project, index) => (

        <div
          key={project.id}
           onMouseEnter={() => {
          setActiveIndex(index);

         const slider = sliderRef.current;

         if (slider) {
           slider.scrollTo({
            left: index * 260,
            behavior: "smooth"
           });
          }
         }}

          style={{
            minWidth:"220px",
            width:"min(220px,70vw)",
            flex:"0 0 auto",

            transform:
              activeIndex === index
                ? "scale(1.08)"
                : "scale(0.95)",

            opacity:
              activeIndex === index
                ? 1
                : 0.6,

            transition:"all .4s ease",

            borderRadius:"20px",
            padding:"14px",

            background: lampOn
              ? "rgba(255,255,255,0.25)"
              : "rgba(25,25,25,0.35)",

            backdropFilter:"blur(14px)",
            WebkitBackdropFilter:"blur(14px)",

            border: lampOn
              ? "1px solid rgba(255,255,255,0.6)"
              : "1px solid rgba(255,255,255,0.15)",

            boxShadow: lampOn
              ? "0 8px 32px rgba(0,0,0,0.08)"
              : "0 8px 32px rgba(0,0,0,0.35)",

            backgroundImage:
              "linear-gradient(120deg, rgba(255,255,255,0.35), rgba(255,255,255,0.05))"
          }}
        >

          <img
            src={project.image} alt="project image"
            style={{
              width:"100%",
              height:"160px",
              objectFit:"cover",
              borderRadius:"10px",
              marginBottom:"10px"
            }}
          />

          <div style={{ fontWeight:"600" }}>
            {project.title}
          </div>

          <div style={{ fontSize:"13px", opacity:0.7 }}>
            {project.short}
          </div>

        </div>

      ))}

    </div>

  );
}