"use client";

export default function HeroText({ lampOn }) {

 return (
  <>
      {/* LEFT TEXT */}

      
  <div className="hero-side hero-left">
    <div
      style={{
        fontSize: "clamp(20px, 2.2vw, 28px)",
        color: lampOn ? "#555" : "#aaa",
        marginBottom: "10px",
      }}
    >
      👋 Hi! I am
    </div>

    <div
      style={{
        fontSize: "clamp(34px, 4.8vw, 72px)",
        fontWeight: "700",
        letterSpacing: "-1px",
        color: lampOn ? "#111" : "#fff",
        lineHeight: "1.05",
      }}
    >
      Nitesh Gupta
    </div>
  </div>

  <div className="hero-side hero-right">
    <div
      style={{
        fontSize: "clamp(18px, 2vw, 24px)",
        color: lampOn ? "#666" : "#aaa",
        marginBottom: "6px",
      }}
    >
      A
    </div>

    <div
      style={{
        fontSize: "clamp(34px, 5vw, 72px)",
        fontWeight: "700",
        lineHeight: "1",
        background: "linear-gradient(90deg,#cce4ff,#1e3a5f)",
        WebkitBackgroundClip: "text",
        color: "transparent",
      }}
    >
      FULL-STACK
    </div>

    <div
      style={{
        fontSize: "clamp(28px, 4.2vw, 56px)",
        fontWeight: "700",
        color: lampOn ? "#111" : "#fff",
        lineHeight: "1.05",
      }}
    >
      DEVELOPER
    </div>
  </div>

  <div className="hero-mobile-text">
    <div
      style={{
        fontSize: "18px",
        color: lampOn ? "#555" : "#aaa",
        marginBottom: "8px",
      }}
    >
      👋 Hi! I am
    </div>

    <div
      style={{
        fontSize: "clamp(28px, 4.2vw, 56px)",
        fontWeight: "700",
        color: lampOn ? "#111" : "#fff",
        lineHeight: "1.05",
        marginBottom: "10px",
      }}
    >
      Nitesh Gupta
    </div>

    <div
      style={{
        fontSize: "16px",
        color: lampOn ? "#666" : "#aaa",
      }}
    >
      A
    </div>

    <div
      style={{
        fontSize: "clamp(28px, 8vw, 42px)",
        fontWeight: "700",
        background: "linear-gradient(90deg,#cce4ff,#1e3a5f)",
        WebkitBackgroundClip: "text",
        color: "transparent",
        lineHeight: "1",
      }}
    >
      FULL-STACK
    </div>

    <div
      style={{
        fontSize: "clamp(28px, 8vw, 42px)",
        fontWeight: "700",
        color: lampOn ? "#111" : "#fff",
        lineHeight: "1.05",
      }}
    >
      DEVELOPER
    </div>
  </div>
 </>

  );
}