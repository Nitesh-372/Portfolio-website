"use client";

export default function AvatarContainer({ lampOn, chatMode, resetChat }) {

  return (

    <div
      onClick={() => {
        if(chatMode){
          resetChat();
        }
      }}
      style={{
       position: "relative",
       left: "auto",
       top: "auto",
       transform: "none",
       marginTop: chatMode ? "0" : "10px",
       marginBottom: chatMode ? "0" : "10px",


        width: chatMode ? "110px" : "min(250px,26vw)",
        height: chatMode ? "110px" : "min(340px,42vh)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",


        borderRadius: "20px",
        overflow: "hidden",

        backgroundColor: lampOn ? "#fff" : "#000",

        transition: "all .5s ease",
        animation: "avatarFloat 4s ease-in-out infinite",
        zIndex: 3,
      }}
    >

      <img
        src={lampOn ? "/lightimg.png" : "/darkimg.png"} 
        alt=" Nitesh Guptaavatar"
        style={{
          width: "100%",
          height: "100%",
          objectFit: "contain",
          transition: "opacity .5s ease"
        }}
      />

    </div>

  );

}