"use client";

export default function ContactSection({ lampOn }) {

  const contacts = [
    {
      name: "Email ",
      link: "mailto:nitesh@example.com"
    },
    {
      name: "GitHub",
      link: "https://github.com/yourgithub"
    },
    {
      name: "LinkedIn",
      link: "https://linkedin.com/in/yourprofile"
    },
    {
      name: "Twitter",
      link: "https://twitter.com/yourhandle"
    }
  ];
  

  
  return (

    <div
      style={{
        width: "100%",
        maxWidth: "500px",
        display: "flex",
        flexDirection: "column",
        gap: "12px"
      }}
    >

      {contacts.map((item, index) => (
        

        <a
          key={index}
          href={item.link}
          target="_blank"
          rel="noreferrer"
          style={{ textDecoration: "none" }}
        >

          <div
            style={{
              padding: "12px 18px",
              borderRadius: "16px",

              background: lampOn
                ? "rgba(255,255,255,0.25)"
                : "rgba(25,25,25,0.35)",

              backdropFilter: "blur(12px)",

              border: lampOn
                ? "1px solid rgba(255,255,255,0.6)"
                : "1px solid rgba(255,255,255,0.15)",

              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",

              cursor: "pointer",
              transition: "all .25s ease"
            }}
          >

            <span>{item.name}</span>

            <span>→</span>

          </div>

        </a>
        

      ))}

    </div>
  );
}