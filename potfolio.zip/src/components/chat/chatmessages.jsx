"use client";
import { useEffect, useRef } from "react";
import ProjectsCarousel from "@/components/projects/projectcarousel";
import ProfileSection from "@/components/profile/profilesection";
import SkillsSection from "@/components/skills/skillsection";
import ContactSection from "@/components/contact/contactsection";
export default function ChatMessages({ messages, lampOn }) {

  const chatRef = useRef(null);

  useEffect(() => {
    const container = chatRef.current;

  if (!container) return;

  const scroll = () => {
    container.scrollTop = container.scrollHeight;
  };

  scroll();

  const observer = new ResizeObserver(scroll);

  observer.observe(container);

  return () => observer.disconnect();

  }, [messages]);

  return (

    <div
      ref={chatRef}
      className="hide-scrollbar"
      style={{
        width: "100%",
        maxWidth: "820px",
        height: messages.length ? "min(430px,45vh)" : "0px",
        minHeight:messages.length ? "140px":"0px",
        padding: messages.length ? "16px" : "0px",
        transition: "all .3s ease",
        overflowY: "auto",
        display: "flex",
        flexDirection: "column",
        padding: "16px",
        gap: "10px"
      }}
    >

      {messages.map((msg, index) => (

        <div
          key={index}
          style={{
            alignSelf:
              msg.role === "user"
                ? "flex-end"
                : "flex-start",

            backgroundColor:
              msg.type === "projects" || msg.type === "profile" 
             ? "transparent":
              msg.role === "user"
                ? lampOn ? "#ddd" : "#333"
                : lampOn ? "#cce4ff" : "#1e3a5f",

            color: lampOn ? "#000" : "#fff",

            padding: "10px 14px",
            borderRadius: "20px",
            maxWidth: "85%"
          }}
        >
          {msg.type === "projects" && (
         <ProjectsCarousel lampOn={lampOn}/>
         
            )}
            {msg.type === "profile" && (
              <div
                style={{
                width: "100%",
                display: "flex",
                justifyContent: "center",
                marginTop: "10px",
               marginBottom: "20px"
                }}
                  >
              <ProfileSection lampOn={lampOn} />
             </div>
            )}
            {msg.type === "skills" && (
             <SkillsSection lampOn={lampOn} />
            )}
            {msg.type === "contact" && (
              <div
                style={{
                width: "100%",
                display: "flex",
                justifyContent: "center",
                marginTop: "10px",
               marginBottom: "20px"
                }}
                  >
            <ContactSection lampOn={lampOn} />
              </div>
            )}

              {msg.text}

          {msg.type ==="resume" && (

            <div
              style={{
                marginTop: "12px",
                padding: "12px",
                borderRadius: "14px",

                background: lampOn
                  ? "rgba(255,255,255,0.35)"
                  : "rgba(20,20,20,0.5)",

                backdropFilter: "blur(10px)",
                border: "1px solid rgba(255,255,255,0.2)",

                display: "flex",
                flexDirection: "column",
                gap: "10px",

                width: "220px"
              }}
            >

              {/* File Info */}
              <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>

                <span style={{ fontSize: "20px" }}>📄</span>

                <div>
                  <div style={{ fontWeight: "600" }}>
                    Resume.pdf
                  </div>

                  <div style={{ fontSize: "12px", opacity: "0.7" }}>
                    Developer Resume
                  </div>
                </div>

              </div>


              {/* Buttons */}
              <div style={{ display: "flex", gap: "10px" }}>

                <a href="/Nitesh_Gupta_1RF23CS104 (1).pdf" target="_blank">
                  <button
                    style={{
                      padding: "6px 12px",
                      borderRadius: "10px",
                      border: "none",
                      cursor: "pointer",

                      background: "#3b82f6",
                      color: "#fff",

                      fontSize: "13px",
                      transition: "all .2s ease"
                    }}

                    onMouseEnter={(e) => {
                      e.currentTarget.style.transform = "scale(1.05)";
                    }}

                    onMouseLeave={(e) => {
                      e.currentTarget.style.transform = "scale(1)";
                    }}
                  >
                    View
                  </button>
                </a>


                <a href="/Nitesh_Gupta_1RF23CS104 (1).pdf" download>
                  <button
                    style={{
                      padding: "6px 12px",
                      borderRadius: "10px",
                      border: "none",
                      cursor: "pointer",

                      background: "#10b981",
                      color: "#fff",

                      fontSize: "13px",
                      transition: "all .2s ease"
                    }}

                    onMouseEnter={(e) => {
                      e.currentTarget.style.transform = "scale(1.05)";
                    }}

                    onMouseLeave={(e) => {
                      e.currentTarget.style.transform = "scale(1)";
                    }}
                  >
                    Download
                  </button>
                </a>

              </div>

            </div>

          )}

        </div>

      ))}

    </div>
  );
}