const projects = [
  {
    id: 1,
    title: "AI Portfolio Assistant",
    image: "/projects/portfolio.png",
    short: "Interactive AI portfolio with avatar.",
    description:
      "A portfolio that lets visitors interact with an AI avatar to explore projects, skills and resume.",
    github: "https://github.com/yourrepo"
  },

  {
    id: 2,
    title: "Mental Health Chatbot",
    image: "/projects/chatbot.png",
    short: "Emotion-aware chatbot in C++.",
    description:
      "A chatbot that detects emotions from user messages and responds with supportive messages.",
    github: "https://github.com/yourrepo"
  },

  {
    id: 3,
    title: "Image Restoration (Restormer)",
    image: "/projects/restormer.png",
    short: "Deep learning image restoration.",
    description:
      "Research project implementing Restormer architecture for removing weather degradation from images.",
    github: "https://github.com/yourrepo"
  }
];

export default projects;