"use client";

import { useState } from "react";
import fakeReplies from "@/data/fakereplies";

export default function useChat() {

  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [chatMode, setChatMode] = useState(false);

  const resetChat = () => {
    setChatMode(false);
    setMessages([]);
  };

  const sendMessage = (text) => {

    const userText = text || input;

    if (!userText.trim()) return;

    setChatMode(true);

    setInput("");
    if(userText === "Me"){

    setMessages(prev => [
    ...prev,
    { role:"user", text:userText },
    { role:"ai", text:"Here's a little about me." },
    { role:"ai", type:"profile" }
   ]);

    return;
   }
   if(userText === "Skills"){

   setMessages(prev => [
    ...prev,
    { role:"user", text:userText },
    { role:"ai", text:"Here are the technologies I work with." },
    { role:"ai", type:"skills" }
   ]);

   return;
  }
  if(userText === "Contacts"){

  setMessages(prev => [
    ...prev,
    { role:"user", text:userText },
    { role:"ai", text:"You can reach me here." },
    { role:"ai", type:"contact" }
  ]);

  return;
}

    /* -------------------------
       PROJECTS MESSAGE
    ------------------------- */

    if (userText === "Projects") {

      setMessages(prev => [
        ...prev,
        { role: "user", text: userText },
        { role: "ai", text: "I have built many projects like following:" },
        { role: "ai", type: "projects" }
      ]);

      return;
    }

    /* -------------------------
       RESUME MESSAGE
    ------------------------- */

    if (userText === "Resume") {

      setMessages(prev => [
        ...prev,
        { role: "user", text: userText },
        {
          role: "ai",
          text: "You can view or download my resume below.",
          type: "resume"
        }
      ]);

      return;
    }

    /* -------------------------
       NORMAL TEXT MESSAGE
    ------------------------- */

    let reply = fakeReplies[userText] || "Ask me about my projects, skills, resume, or contact details.";


    setMessages(prev => [
      ...prev,
      { role: "user", text: userText },
      { role: "ai", text: "" }
    ]);

    setIsTyping(true);

    let index = 0;

    const typingInterval = setInterval(() => {

      index++;

      setMessages(prev => {

        const updated = [...prev];

        const lastIndex = updated.length - 1;

        updated[lastIndex].text = reply.slice(0, index);

        return updated;
      });

      if (index === reply.length) {
        clearInterval(typingInterval);
        setIsTyping(false);
      }

    }, 40);

  };

  return {
    messages,
    input,
    setInput,
    sendMessage,
    isTyping,
    chatMode,
    setChatMode,
    resetChat
  };
}