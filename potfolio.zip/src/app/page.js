"use client";

import useChat from "@/hooks/usechat";
import useTheme from "@/hooks/usetheme";

import ChatMessages from "@/components/chat/chatmessages";
import ChatInput from "@/components/chat/chatinput";
import PromptButtons from "@/components/chat/promtbutton";
import CanvasCursor from "@/components/cursor/canvascursor";
import FluidCursor from "@/components/cursor/fluidcursor";


import HeroIntro from "@/components/hero/herointro";

import Lamp from "@/components/lamp/lamp";
import LightCone from "@/components/lamp/lightcone";
import AvatarContainer from "@/components/avatar/Avatarcontainer";
import ProjectCarousel from "@/components/projects/projectcarousel";

export default function Home() {

  const { messages, input, setInput, sendMessage , chatMode, resetChat } = useChat();

  const { lampOn, bounce, toggleLamp } = useTheme();

  return (

    <main
      style={{
        minHeight: "100vh",
        width: "100%",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "flex-start",
        backgroundColor: lampOn ? "#fff" : "#000",
        color: lampOn ? "#000" : "#fff",
        transition: "background-color .5s ease",
        position: "relative",
        width: "100%",
        padding: "24px 16px 40px",
        overflow: "hidden"

       
      }}
    >
      {!chatMode &&(

      <Lamp
        lampOn={lampOn}
        toggleLamp={toggleLamp}
        bounce={bounce}
      />
       )}
       {lampOn && !chatMode &&(

      <LightCone lampOn={lampOn} />
      )}
     <div
  style={{
    position: "relative",
    width: "100%",
    maxWidth: "1400px",
    minHeight:chatMode ? "180px":"640px",
    marginTop: chatMode ? "160px" : "0",
    display: "flex",
    justifyContent: "center",
    flexDirection: "column",
    alignItems: "center",
    gap: "10px",
    zIndex: 6
  }}
> 

  {!chatMode && <HeroIntro lampOn={lampOn} />}

  {!chatMode && (
    <Lamp
      lampOn={lampOn}
      toggleLamp={toggleLamp}
      bounce={bounce}
    />
  )}

  {lampOn && !chatMode && <LightCone lampOn={lampOn} />}

  <AvatarContainer
    lampOn={lampOn}
    chatMode={chatMode}
    resetChat={resetChat}
  />
</div>
<div
  style={{
    width: "100%",
    maxWidth: "900px",
    marginTop: chatMode ? "20px" : "-20px",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    gap: "12px",
    zIndex: 6,
  }}
>
  <ChatMessages messages={messages} lampOn={lampOn} />

  <ChatInput
    input={input}
    setInput={setInput}
    sendMessage={sendMessage}
    lampOn={lampOn}
  />

  <PromptButtons
    sendMessage={sendMessage}
    lampOn={lampOn}
  />
</div>

  {lampOn && (
 
    <FluidCursor />

)}
    {!lampOn &&(
    <CanvasCursor />)}

      <AvatarContainer
        lampOn={lampOn}
        chatMode={chatMode}
        resetChat={resetChat}
      />

    </main>

  );
}